﻿const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

module.exports = member => {
    let username = member.user.username;
     member.sendMessage('**Sunucumuza Hoşgeldin ' + username + '\n 7/24 Aktif Sunucudur Bende Diyerleri Gibi Büyümeye Çalişiyorum :heart: \n  Beni kırmayıp gelirmisin? Canım :heart:\n BU BOT TAMMAMEN KAAN UYAR TARAFİNDAN YAPİLMİSTİR \n Sınırsız Davet Linki: https://discord.gg/TADw6KV **');
};