﻿const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client();
const ayarlar = require('./ayarlar.json');


client.on('ready', () => { // client (botumuz) hazır olduğunda
  client.user.setActivity('Spotify', { type: "LISTENING"}); // oynuyor kısmını "Seninle" yapsın
  console.log(`Hazırım!`); // konsola "Hazırım" yazsın
});
client.on("guildMemberAdd", member => {
    member.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\nhttps://discord.gg/yPr5XsU');

    //member.guild.defaultChannel.sendMessage(`Welcome "${member.user.username}"! Be sure to set your platform by typing "!role"`);
})
client.on("guildMemberRemove", member => {
    member.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU');

    //member.guild.defaultChannel.sendMessage(`Welcome "${member.user.username}"! Be sure to set your platform by typing "!role"`);
})


client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'sa') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'mute') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'hb') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'as') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'oç') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'partner') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'tm') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'ağla') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})

client.on("message", async message =>{
  if (message.content.toLowerCase()=== 'hm') {
message.author.send('Selam dostum muhabbet, mizah, arkadaş istiyorsan burası tam sana göre\n https://discord.gg/yPr5XsU')
  }
})
client.on("guildCreate", guild => {
  console.log(`Yeni sunucuya katıldım: ${guild.name}\n. Bu sunucu ${guild.memberCount} üye!`);
});
client.on("guildDelete", guild => {
  console.log(`Hey beni çıkardılar ;(: ${guild.name}`);
});



client.login(ayarlar.token);